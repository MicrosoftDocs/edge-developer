chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "setBadgeText") {
    chrome.browserAction.setBadgeText({
      text: request.text ? request.text : '',
      tabId: request.tabId
    });
    sendResponse({ message: "setBadgeText completed" });
  }
  return true;
});
