function save_options() {
  const nasaApiKey = document.getElementById("nasaApiKey").value;
  const useNasaApi = document.getElementById("useNasaApi").checked;
  chrome.storage.sync.set(
    {
      nasaApiKey: nasaApiKey,
      useNasaApi: useNasaApi
    },
    function() {
      const status = document.getElementById("status");
      status.textContent = "Options saved.";
      setTimeout(function() {
        status.textContent = "";
      }, 750);
    }
  );
}

function restore_options() {
  chrome.storage.sync.get(
    {
      nasaApiKey: "DEMO_KEY",
      useNasaApi: false
    },
    function(items) {
      document.getElementById("nasaApiKey").value = items.nasaApiKey;
      document.getElementById("useNasaApi").checked =
        items.useNasaApi;
    }
  );
}

window.onload = function() {
  restore_options();
};

// document.addEventListener("DOMContentLoaded", restore_options);

const elementSave = document.getElementById("save");
if (elementSave) {
  elementSave.addEventListener("click", save_options);
}
