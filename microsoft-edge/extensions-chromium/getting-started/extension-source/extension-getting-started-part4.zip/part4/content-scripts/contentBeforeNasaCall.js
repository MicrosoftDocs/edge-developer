chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  $("head").prepend(
    `<style>
       .slide-image {
          height: auto;
          width: 100vw;
        }
      </style> `
  );
  chrome.storage.sync.get(["useNasaApi", "nasaApiKey"], result => {
    $("body").prepend(
      `
        <img  src="${request.url}" id="${request.imageDivId}" 
           class="slide-image" />
           
        <ul>
          <li>useNasaApi:${result.useNasaApi}</li>
          <li>nasaApiKey:${result.nasaApiKey}</li>
        </ul>
      `
    );
    $(`#${request.imageDivId}`).click(function() {
      $(`#${request.imageDivId}`).remove(`#${request.imageDivId}`);
    });
    sendResponse({ fromcontent: "This message is from content.js" });
  });
  return true; // forces sendMessage to wait for sendMessage before exiting
});
