chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  $("head").prepend(
    `<style>
       .slide-image {
          height: auto;
          width: 100vw;
        }
      </style> `
  );
  chrome.storage.sync.get(["useNasaApi", "nasaApiKey"], result => {
    if (result.useNasaApi && result.useNasaApi === true) {
      const url = `https://api.nasa.gov/planetary/apod?api_key=${
        result && result.nasaApiKey ? result.nasaApiKey : "DEMO_KEY"
      }`;
      $.ajax({
        url,
        type: "GET",
        datatype: "json",
        success: function (data) {
          if (data && data.url) {
            updateHtml(data.url);
          } else {
            alert(`api call failed to ${url}`);
          }
        },
        error: function (jqXHR) {
          const errorMessage =
            jqXHR && jqXHR.responseText
              ? JSON.parse(jqXHR.responseText).error.message
              : "error calling NASA API";
          alert(errorMessage);
        }
      });
    } else {
      updateHtml(request.url);
    }
    function updateHtml(imageUrl) {
      $("body").prepend(
        `<img  src="${imageUrl}" id="${request.imageDivId}" 
           class="slide-image" />`
      );
      $(`#${request.imageDivId}`).click(function() {
        $(`#${request.imageDivId}`).remove(`#${request.imageDivId}`);
      });
      sendResponse({ fromcontent: "This message is from content.js" });
    }
  });
  return true; // forces sendMessage to wait for sendMessage before exiting
});
