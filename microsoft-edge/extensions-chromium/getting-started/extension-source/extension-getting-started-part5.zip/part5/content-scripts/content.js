chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  $("head").prepend(
    `<style>
       .slide-image {
          height: auto;
          width: 100vw;
        }
      </style> `
  );
  chrome.storage.sync.get(["useNasaApi", "nasaApiKey"], result => {
    function updateBadgeText(pictureDate) {
      const badgeText = pictureDate
        ? ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][
            new Date(`${pictureDate}T00:00:00`).getDay()
          ]
        : "";
      chrome.runtime.sendMessage(
        { action: "setBadgeText", text: badgeText, tabId: request.tabId },
        function(response) {
          console.log(response);
        }
      );
    }
    if (result.useNasaApi && result.useNasaApi === true) {
      const NASA_POD_LOCALSTORAGE_KEY = "NASA_POD_LOCALSTORAGE_KEY";
      const dataObjectString = window.localStorage.getItem(
        NASA_POD_LOCALSTORAGE_KEY
      );
      const dataObject = dataObjectString ? JSON.parse(dataObjectString) : {};
      if (
        dataObject &&
        dataObject.localStorageSetDate &&
        needToUpdateNasaPod(dataObject.localStorageSetDate, 60)
      ) {
        const url = `https://api.nasa.gov/planetary/apod?api_key=${
          result && result.nasaApiKey ? result.nasaApiKey : "DEMO_KEY"
        }`;
        $.ajax({
          url,
          type: "GET",
          datatype: "json",
          success: function(data) {
            function fixUrlForVideo(data) {
              return data.media_type && data.media_type === "video" ? `https://img.youtube.com/vi/${
                data.url.split("/").pop().split("?")[0]
              }/hqdefault.jpg` : data.url;
            }
            if (data && data.url) {
              data.url = fixUrlForVideo(data);
              data.localStorageSetDate = new Date().getTime();
              window.localStorage.setItem(
                NASA_POD_LOCALSTORAGE_KEY,
                JSON.stringify(data)
              );
              updateBadgeText(data.date);
              updateHtml(data.url);
              sendResponse({ fromcontent: "content updated from API" });
            } else {
              alert(`api call failed to ${url}`);
              sendResponse({ fromcontent: "API update failed" });
            }
          },
          error: function(jqXHR) {
            const errorMessage =
              jqXHR && jqXHR.responseText
                ? JSON.parse(jqXHR.responseText).error.message
                : "error calling NASA API";
            alert(errorMessage);
            sendResponse({ fromcontent: `API update failed: ${errorMessage}` });
          }
        });
      } else {
        // found in cache
        updateBadgeText(dataObject.date);
        updateHtml(dataObject.url);
        sendResponse({ fromcontent: "content update from cache" });
      }

      function needToUpdateNasaPod(nasaLastGetDate, minutesToCheckBack) {
        if (!nasaLastGetDate) return true;
        const currentDateTime = new Date().getTime();
        const lastCheckDateTime = new Date(nasaLastGetDate).getTime();
        const minutesSinceLastCheck =
          (currentDateTime - lastCheckDateTime) / (1000 * 60);
        return minutesSinceLastCheck > minutesToCheckBack;
      }
    } else {
      updateHtml(request.url);
      sendResponse({ fromcontent: "content update from static image" });
    }
    function updateHtml(imageUrl) {
      $("body").prepend(
        `<img  src="${imageUrl}" id="${request.imageDivId}" 
           class="slide-image" />`
      );
      $(`#${request.imageDivId}`).click(function() {
        $(`#${request.imageDivId}`).remove(`#${request.imageDivId}`);
        updateBadgeText(); // clear badge text
      });
    }
  });
  return true; // forces sendMessage to wait for sendMessage before exiting
});